import React from 'react';

const Heading1 = ({ text }) => {
  return <h1 className="text-center mb-4">{text}</h1>;
};

export default Heading1;
